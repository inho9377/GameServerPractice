#include "UiManager.h"



CUiManager::CUiManager()
{
}


CUiManager::~CUiManager()
{
}
